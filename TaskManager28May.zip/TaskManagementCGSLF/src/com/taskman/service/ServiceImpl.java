package com.taskman.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.taskman.dao.Messages;
import com.taskman.dao.UserDataAccess;
import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.User;
import com.taskman.exception.ApplicationException;

@Component("userService")
public class ServiceImpl implements Service {

	@Autowired
	UserDataAccess allDao;

	@Override
	public boolean validate(Login login) throws ApplicationException {
		// TODO Auto-generated method stub
		return allDao.validate(login);
	}

	@Override
	public int insertRec(User user) throws ApplicationException {
		// TODO Auto-generated method stub
		String skills = ""; //$NON-NLS-1$
		for (String skl : user.getSkillSet()) {
			skills = skills + skl + Messages.getString("UserDao.2"); //$NON-NLS-1$
		}
		skills = skills.trim();		
		return allDao.insertRec(user);
	}

	@Override
	public List fetchContacts() throws ApplicationException {
		// TODO Auto-generated method stub
		return allDao.fetchContacts();
	}

	@Override
	public int updateStatus(String pId, String status, String userId) throws ApplicationException {
		// TODO Auto-generated method stub
		return allDao.updateStatus(pId, status, userId);
	}

	@Override
	public List fetchUsers() throws ApplicationException {
		// TODO Auto-generated method stub
		return allDao.fetchUsers();
	}

	@Override
	public List fetchTask() throws ApplicationException {
		// TODO Auto-generated method stub
		return allDao.fetchTask();
	}

	@Override
	public List fetchTask(String id) throws ApplicationException {
		// TODO Auto-generated method stub
		return allDao.fetchTask(id);
	}

	@Override
	public Task fetchtask(String taskId) {
		// TODO Auto-generated method stub
		return allDao.fetchtask(taskId);
	}

	@Override
	public int insertTask(Task task) throws ApplicationException {
		// TODO Auto-generated method stub
		return allDao.insertTask(task);
	}

}
