package com.taskman.controller;
/************************************************************************************
 * File:        UserController.java
 * Package:     com.taskman.controller
 * Description: Controller class for Task Management System that handles all 
 * 				client requests and responses after performing necessary operations
 * Version:     1.0
 * Modifications:
 * Author: akuma516      Date: 24th-may-2018      Change Description:
 ************************************************************************************/

import java.util.ArrayList;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.User;
import com.taskman.exception.ApplicationException;
import com.taskman.service.Service;

/**
 * @author akuma516
 *
 */
@Scope("session")
@Controller
@RequestMapping(value = "user")
public class UserController {

	private static Logger logger = Logger.getLogger(com.taskman.controller.UserController.class);
	
	ArrayList<String> cityList;
	ArrayList<String> skillList;
	@Autowired
	Service allService;

	/*
	 * @Autowired private HttpSession session;
	 */
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/showLogin")
	public String prepareLogin(Model model) {
		logger.info(Messages.getString("UserController.InPrepareLogin"));
		System.out.println(Messages.getString("UserController.InPrepareLogin")); //$NON-NLS-1$
		model.addAttribute(Messages.getString("UserController.login"), new Login()); //$NON-NLS-1$
		return Messages.getString("UserController.login"); //$NON-NLS-1$
	}

	/**
	 * @param userId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/createTask")
	public String createTask(@RequestParam("userId") String userId, Model model, HttpSession session) {
		try {
			logger.info("UserController.inCreateTask");
			System.out.println("UserController.inCreateTask"); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.userId"), userId); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.task"), new Task()); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.users"), allService.fetchUsers()); //$NON-NLS-1$
			return Messages.getString("UserController.createTask"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}

	/**
	 * @param assignedTo
	 * @param userId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/assignTask")
	public String assignTask(@RequestParam("pId") String assignedTo, @RequestParam("userId") String userId, Model model,
			HttpSession session) {
		try {
			System.out.println(Messages.getString("UserController.inAssignTask")); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.userId"), userId); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.assignedTo"), assignedTo); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.task"), new Task()); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.users"), allService.fetchUsers()); //$NON-NLS-1$
			return Messages.getString("UserController.createTask"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}

	/**
	 * @param userId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/showTask")
	public String showTask(@RequestParam("userId") String userId, Model model, HttpSession session) {
		try {
			System.out.println(Messages.getString("UserController.inShowTask")); //$NON-NLS-1$
			System.out.println(allService.fetchTask());

			model.addAttribute(Messages.getString("UserController.userId"), userId); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.list"), allService.fetchTask()); //$NON-NLS-1$
			return Messages.getString("UserController.task"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}

	/**
	 * @param userId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/showContacts")
	public String showContacts(@RequestParam("pId") String userId, Model model, HttpSession session) {
		try {
			System.out.println(Messages.getString("UserController.inShowContact")); //$NON-NLS-1$
			System.out.println(allService.fetchContacts());

			model.addAttribute(Messages.getString("UserController.userId"), userId); //$NON-NLS-1$
			model.addAttribute(Messages.getString("UserController.list"), allService.fetchContacts()); //$NON-NLS-1$
			return Messages.getString("UserController.showContacts"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}

	/**
	 * @param userId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/showTaskForU")
	public String showTaskForU(@RequestParam("userId") String userId, Model model, HttpSession session) {
		try {
			System.out.println(Messages.getString("UserController.inShowTaskMethod")); //$NON-NLS-1$
			System.out.println(allService.fetchTask(userId));

			model.addAttribute(Messages.getString("UserController.list"), allService.fetchTask(userId)); //$NON-NLS-1$
			return Messages.getString("UserController.task"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}

	/**
	 * @param task
	 * @param result
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/insertTask", method = RequestMethod.POST)
	public String insertTask(@ModelAttribute("task") @Valid Task task, BindingResult result, Model model,
			HttpSession session) {
		try {
			String string = Messages.getString("UserController.inInsertTask"); //$NON-NLS-1$
			System.out.println(string);
			if (result.hasErrors()) {
				return Messages.getString("UserController.error"); //$NON-NLS-1$
			}
			int itrSuccess = allService.insertTask(task);
			model.addAttribute(Messages.getString("UserController.task"), task); //$NON-NLS-1$
			if (itrSuccess != 0) {
				return Messages.getString("UserController.taskSuccess"); //$NON-NLS-1$
			} else
				return Messages.getString("UserController.error"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}

	/**
	 * @param pId
	 * @param status
	 * @param userId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping("/update")
	public String updateStatus(@RequestParam("pId") String pId, @RequestParam("status") String status,
			@RequestParam("userId") String userId, Model model, HttpSession session) {
		try {
			System.out.println(Messages.getString("UserController.inAssignTaskAsInfo") + pId //$NON-NLS-1$
					+ Messages.getString("UserController.status") + status //$NON-NLS-1$
					+ Messages.getString("UserController.userIdasSpace") + userId); //$NON-NLS-1$
			int itrSuccess = allService.updateStatus(pId, status, userId);
			return Messages.getString("UserController.updateSuccess"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}

	/**
	 * @param task
	 * @param pId
	 * @param userId
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping("/updateTask")
	public String loadUpdateTask(@ModelAttribute("task") @Valid Task task, @RequestParam("pId") String pId,
			@RequestParam("userId") String userId, Model model, HttpSession session) {
		System.out.println(Messages.getString("UserController.inAssignTaskasInfoUser") + pId //$NON-NLS-1$
				+ Messages.getString("UserController.userIdasSpace") + userId); //$NON-NLS-1$
		model.addAttribute(Messages.getString("UserController.pId"), pId); //$NON-NLS-1$
		model.addAttribute(Messages.getString("UserController.userIdSpecial"), userId); //$NON-NLS-1$
		return Messages.getString("UserController.updateStatus"); //$NON-NLS-1$

	}

	/**
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return Messages.getString("UserController.login"); //$NON-NLS-1$
	}

	/**
	 * @param login
	 * @param result
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login login, BindingResult result, Model model,
			HttpSession session) {
		try {
			logger.info("on checklogin");
			System.out.println(session.getCreationTime());
			session.invalidate();
			System.out.println(Messages.getString("UserController.inCheckLogin")); //$NON-NLS-1$

			if (result.hasErrors())
				return Messages.getString("UserController.login"); //$NON-NLS-1$

			// Logic to validate userName and password against database
			System.out.println(Messages.getString("UserController.Dao") + allService); //$NON-NLS-1$
			boolean userPresent = allService.validate(login);
			model.addAttribute(Messages.getString("UserController.user"), login); //$NON-NLS-1$

			if (userPresent)
				return Messages.getString("UserController.loginSuccess"); //$NON-NLS-1$
			else
				return Messages.getString("UserController.loginFailed"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}

	}

	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/showRegister")
	public String prepareRegister(Model model) {
		cityList = new ArrayList<String>();
		cityList.add(Messages.getString("UserController.Pune")); //$NON-NLS-1$
		cityList.add(Messages.getString("UserController.Mumbai")); //$NON-NLS-1$
		cityList.add(Messages.getString("UserController.Banglore")); //$NON-NLS-1$
		cityList.add(Messages.getString("UserController.Chennai")); //$NON-NLS-1$
		cityList.add(Messages.getString("UserController.Delhi")); //$NON-NLS-1$

		skillList = new ArrayList<String>();

		skillList.add(Messages.getString("UserController.java")); //$NON-NLS-1$
		skillList.add(Messages.getString("UserController.mainframe")); //$NON-NLS-1$
		skillList.add(Messages.getString("UserController.ODS")); //$NON-NLS-1$
		skillList.add(Messages.getString("UserController.Testing")); //$NON-NLS-1$

		model.addAttribute(Messages.getString("UserController.cityList"), cityList); //$NON-NLS-1$
		model.addAttribute(Messages.getString("UserController.skillList"), skillList); //$NON-NLS-1$

		model.addAttribute(Messages.getString("UserController.user"), new User()); //$NON-NLS-1$
		return Messages.getString("UserController.register"); //$NON-NLS-1$
	}

	/**
	 * @param user
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/checkRegister")
	public String checkRegister(@ModelAttribute("user") @Valid User user, BindingResult result, Model model) {
		try {
			if (result.hasErrors()) {
				model.addAttribute(Messages.getString("UserController.cityList"), cityList); //$NON-NLS-1$
				model.addAttribute(Messages.getString("UserController.skillList"), skillList); //$NON-NLS-1$
				return Messages.getString("UserController.register"); //$NON-NLS-1$
			}
			int registerSuccess = allService.insertRec(user);
			if (registerSuccess != 0) {
				model.addAttribute(Messages.getString("UserController.user"), user); //$NON-NLS-1$
				return Messages.getString("UserController.registerSuccess"); //$NON-NLS-1$
			} else
				return Messages.getString("UserController.registerFailed"); //$NON-NLS-1$
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e);
			return "error";
		}
	}
}
