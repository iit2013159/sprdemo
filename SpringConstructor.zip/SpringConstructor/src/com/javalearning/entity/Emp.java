package com.javalearning.entity;

public interface Emp {
	public void calculateSalary();
}