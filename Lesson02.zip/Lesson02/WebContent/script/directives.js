/**
 * Custom Directives - Restricting Directives(E-element,A-Attribute,C-class,M-comments)
 */


/* -----------------Angular-Custom Directives---------------------*/
var myapp=angular.module("directiveApp",[]);

/**
 * Its only matches element name
*/
myapp.directive("product", function(){
	
	return {
		restrict:"E",
		template: "<h1>Product Data Coming in element Name ...</h1>"
	}
	
});

/**
 * Its only matches attribute name
*/
myapp.directive("productattr", function(){
	
	return {
		restrict:"A",
		template: "<h1>Product Data Coming in Attribute Name ... ...</h1>"
	}
	
});

/**
 * Its only matches class name
*/
myapp.directive("productclass", function(){
	
	return {
		restrict:"C",
		template: "<h1>Product Data Coming in Class Name ... ...</h1>"
	}
	
});


/**
 * Its only matches comment name
*/
myapp.directive("productcomment", function(){
	
	return {
		restrict:"M",
		replace:true,
		template: "<h1>Product Data Coming in Comment Name ... ...</h1>"
	}
	
});


/**
 * Its only matches attribute or class or Element  name
*/
myapp.directive("productaorcore", function(){
	
	return {
		restrict:"ACE",
		replace:true,
		template: "<h1>Product Data Coming in attribute or class or Element Name ... ...</h1>"
	}
	
});


/*-------------------------------------------------------------------------------*/

myapp.directive("myProduct", function(){
	
	return {
		restrict:"ACE",
		replace:true,
		template: "<h1>Product Data Coming in attribute or class or Element Name ... ...</h1>"
	}
	
});
/*-----------------------------------------SharedScope & Inherited(Angular-SharedScope.html)--------------------------------------*/

var app = angular.module("test",[]);

app.controller("Ctrl1",function($scope){
    $scope.name = "rahul";
    $scope.reverseName = function(){
        $scope.name = $scope.name.split('').reverse().join('');
    };
});
app.directive("myDirective", function(){
    return {
        restrict: "EA",
        scope: true,
        template: "<div>Your name is : {{name}}</div>"+
        "Change your name : <input type='text' ng-model='name' />"
    };
});

/*-----------------------------------------        Isolated (Angular-IsolatedScope.html)            --------------------------------------*/
var app = angular.module("app", []);
app.controller("MainCtrl", function( $scope ){
    $scope.name = "Rahul";
    $scope.color = "#333333";
    $scope.reverseName = function(){
    	
     $scope.name = $scope.name.split("").reverse().join("");
    };
    $scope.randomColor = function(){
        $scope.color = '#'+Math.floor(Math.random()*16777215).toString(16);
    };
});

app.directive("myDirective", function(){
    
    return {
        restrict: "EA",
        scope: {
            name: "@",
            color: "=",
            reverse: "&"
        },
        template: [
            "<div class='line'>",
            "Name : <strong>{{name}}</strong>;  Change name:<input type='text' ng-model='name' /><br/>",
            "</div><div class='line'>",
            "Color : <strong style='color:{{color}}'>{{color|uppercase}}</strong>;  Change color:<input type='text' ng-model='color' /><br/></div>",
            "<br/><input type='button' ng-click='reverse()' value='Reverse Name'/>"
        ].join("")    
    };
});
