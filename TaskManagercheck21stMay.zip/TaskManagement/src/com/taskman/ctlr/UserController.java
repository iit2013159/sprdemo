package com.taskman.ctlr;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.taskman.dao.UserDao;
import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.User;


@Scope("session")
@Controller
@RequestMapping(value="user")
public class UserController {
	
	ArrayList<String> cityList;
	ArrayList<String> skillList;
	
	@Autowired
	UserDao allDao;
	
	@RequestMapping(value="/showLogin")
	public String prepareLogin(Model model)
	{
		System.out.println("In prepareLogin() method");
		model.addAttribute("login",new Login());
		return "login";
	}
	@RequestMapping(value="/createTask")
	public String createTask(@RequestParam("userId") String userId,Model model)
	{
		System.out.println("In create Task() method");
		model.addAttribute("userId",userId);
		model.addAttribute("task",new Task());
		model.addAttribute("users",allDao.fetchUsers());
		return "createTask";
	}
	@RequestMapping(value="/showTask")
	public String showTask(Model model)
	{
		System.out.println("In showTask() method");
		System.out.println(allDao.fetchTask());
		List l = allDao.fetchTask();
		for(int j = 0; j < l.size();j++) {
			Map st = (Map) l.get(j);
			System.out.println(st.get("id"));
		}
		model.addAttribute("list",allDao.fetchTask());
		return "task";
	}
	
	@RequestMapping(value="/showTaskForU")
	public String showTaskForU(@RequestParam("userId") String userId,Model model)
	{
		System.out.println("In showTaskForU() method");
		System.out.println(allDao.fetchTask(userId));
		List l = allDao.fetchTask();
		for(int j = 0; j < l.size();j++) {
			Map st = (Map) l.get(j);
			System.out.println(st.get("id"));
		}
		model.addAttribute("list",allDao.fetchTask(userId));
		return "task";
	}
	
	@RequestMapping(value="/insertTask", method = RequestMethod.POST)
	public String insertTask(@ModelAttribute("task")@Valid Task task,BindingResult result,Model model)
	{
		System.out.println("In InsertTask method");
		 if(result.hasErrors())
		 {
			 
			 return "error";
		 }
		 
		  int itrSuccess=allDao.insertTask(task);
		  model.addAttribute("task",task);  
		  if(itrSuccess!=0)
		  {             		  
	  	     return "taskSuccess";
		  }
		  else
			 return "error";
	}
	
	@RequestMapping("/updateTask")
	public String loadUpdateTask(@RequestParam("pId") String pId, Model model) {
		return pId;
	
	}
	
	@RequestMapping(value="/checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login login,BindingResult result,Model model)
	{
		System.out.println("in checkLogin()");
		
		if(result.hasErrors())
			return "login";
		
		//Logic to validate userName and password against database
		System.out.println("Dao "+allDao);
		boolean userPresent=allDao.validate(login);
		model.addAttribute("user",login);
		
		if(userPresent)
	  	    return "loginSuccess";
		else
			return "loginFailed";
	}

	@RequestMapping(value="/showRegister")
	public String prepareRegister(Model model)
	{
		cityList =new ArrayList<String>();
		cityList.add("Pune");
		cityList.add("Mumbai");
		cityList.add("Bangalore");
		cityList.add("Chennai");
		cityList.add("Delhi");
		
		skillList =new ArrayList<String>();
		
		skillList.add("Java");
		skillList.add("Mainframe");
		skillList.add("ODS");
		skillList.add("Testing");
		
		model.addAttribute("cityList",cityList);
		model.addAttribute("skillList",skillList);
		
		model.addAttribute("user",new User());
	    return "register";	
	}
	
	@RequestMapping(value="/checkRegister")
	public String checkRegister(@ModelAttribute("user")@Valid User user,BindingResult result,Model model)
	{
		 if(result.hasErrors())
		 {
			 model.addAttribute("cityList",cityList);
    		 model.addAttribute("skillList",skillList);

			 return "register";
		 }
		 
		  int registerSuccess=allDao.insertRec(user);
		  if(registerSuccess!=0)
		  {
             model.addAttribute("user",user);  		  
	  	     return "registerSuccess";
		  }
		  else
			 return "registerFailed";
	}
	
	
	 
	

}
