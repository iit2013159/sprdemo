
drop table ProductDetails;

create table ProductDetails(
pro_id number(7),
pro_name varchar2(20),
pro_price number(8,2),
pro_quantity number(8),
pro_category varchar2(30),
pro_manufactureDate Date,
primary key(pro_id)
)

drop sequence pro_id_seq;

create sequence pro_id_seq start with 1000;

select * from productdetails;

select * from taskallocation;