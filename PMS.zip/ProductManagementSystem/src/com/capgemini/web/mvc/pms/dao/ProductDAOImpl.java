package com.capgemini.web.mvc.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.capgemini.web.mvc.pms.dto.Product;
import com.capgemini.web.mvc.pms.exception.ProductException;
import com.capgemini.web.mvc.pms.util.DBUtil;

public class ProductDAOImpl implements IProductDAO {

	@Override
	public int addProduct(Product product) throws ProductException 
	{
		int id=0;
		
		try(Connection conn = DBUtil.getConnection())
		{
			//store in database
				//1)ged id from seq
				//2)fire query of db for insert
			//init id
			
			
			Statement stm = conn.createStatement();
			
			ResultSet res = stm.executeQuery("select pro_id_seq.NEXTVAL from dual");
			
			if(res.next() == false)
			{
				throw new Exception("Failed to Generate Product ID");
			}
			
			//setting id to product
			product.setId(res.getInt(1));
			
			//Insert Operation below
			
			PreparedStatement pstm = 
					conn.prepareStatement("insert into ProductDetails values(?,?,?,?,?,?)");
			
			pstm.setInt(1, product.getId());
			pstm.setString(2, product.getName());
			pstm.setDouble(3, product.getPrice());
			pstm.setInt(4, product.getQuantity());
			pstm.setString(5, product.getCategory());
			
			long value = product.getManufactureDate().getTime();//convert util date to long value
			java.sql.Date date = new java.sql.Date(value);//convert long value to sql date
			
			pstm.setDate(6,date );
			pstm.execute();
			
			id= product.getId();//return the product id generated
			
			
			
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		
		return id;
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		Product product=null;
		
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = conn.prepareStatement("select * from ProductDetails where pro_id=?");
			pstm.setInt(1, id);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)
			{
				throw new Exception("No product found with id= "+id);
				
			}
			product = new Product();
			
			product.setId(res.getInt(1));
			product.setName(res.getString(2));
			product.setPrice(res.getDouble(3));
			product.setQuantity(res.getInt(4));
			product.setCategory(res.getString(5));
			product.setManufactureDate(res.getDate(6));
			
		} catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		
		return product;
	}

	@Override
	public void updateProduct(Product product) throws ProductException 
	{
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = 
					conn.prepareStatement("update ProductDetails "+"set pro_name=?, pro_price=?, pro_quantity=?, pro_category=?, pro_manufactureDate=?" +" where pro_id=? ");
			
			pstm.setString(1,product.getName());
			pstm.setDouble(2, product.getPrice());
			pstm.setString(4,product.getCategory());
			pstm.setInt(3, product.getQuantity());
			
			long value = product.getManufactureDate().getTime();//convert util date to long date
			java.sql.Date date = new java.sql.Date(value);//conert lonbg value to sql date
			pstm.setDate(5, date);
			pstm.setInt(6, product.getId());
			pstm.execute();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new ProductException(e.getMessage());
		}

	}

	@Override
	public Product removeProduct(int id) throws ProductException 
	{
		Product product=null;
		
		try(Connection conn = DBUtil.getConnection())
		{
			PreparedStatement pstm = conn.prepareStatement("select * from ProductDetails where pro_id=?");
			pstm.setInt(1, id);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)//no row in resultset hence
			{
				throw new Exception("No product found with id= "+id);
				
			}
			product = new Product();
			
			product.setId(res.getInt(1));
			product.setName(res.getString(2));
			product.setPrice(res.getDouble(3));
			product.setQuantity(res.getInt(4));
			product.setCategory(res.getString(5));
			product.setManufactureDate(res.getDate(6));
			
			
			//remove product
			PreparedStatement pstm2 = conn.prepareStatement("delete from ProductDetails where pro_id=?");
			pstm2.setInt(1, id);
			pstm2.execute();
			
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		return product;
	}

	@Override
	public List<Product> getProducts() throws ProductException 
	{
		
		List<Product> products= null;
		
		try(Connection conn = DBUtil.getConnection())
		{
			Statement stm = conn.createStatement();
			
			ResultSet res = stm.executeQuery("select * from ProductDetails");
			
			products = new ArrayList<Product>();
			
			while(res.next())
			{
				Product currentProduct = new Product();
				
				currentProduct.setId(res.getInt(1));
				currentProduct.setName(res.getString(2));
				currentProduct.setPrice(res.getDouble(3));
				currentProduct.setQuantity(res.getInt(4));
				currentProduct.setCategory(res.getString(5));
				currentProduct.setManufactureDate(res.getDate(6));
				
				products.add(currentProduct);
				
			}
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		
		return products;
	}

}
