package com.capgemini.web.mvc.pms.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.web.mvc.pms.dto.Product;
import com.capgemini.web.mvc.pms.exception.ProductException;
import com.capgemini.web.mvc.pms.service.IProductService;
import com.capgemini.web.mvc.pms.service.ProductServiceImpl;


@WebServlet("/ProductController")
public class ProductController extends HttpServlet 
{
	private IProductService productService;
	
	public ProductController()
	{
		//loose coupling
		productService = new ProductServiceImpl();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request,response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request,response);
		
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//identify the request
		String action =request.getParameter("action");
		
		switch(action)
		{
		//read addProduct form
			case "addPro":
				String name=request.getParameter("name");
				String price=request.getParameter("price");
				String quantity=request.getParameter("quantity");
				String category=request.getParameter("category");
				String manufactureDate=request.getParameter("manufactureDate");
				
				//create a DTO form the form data read
				Product product=new Product();
				product.setName(name);
				product.setPrice(Double.parseDouble(price));
				product.setQuantity(Integer.parseInt(quantity));
				product.setCategory(category);
				
				
				//convert string to util date
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyy");
				LocalDate ld= LocalDate.parse(manufactureDate,formatter);
				Date date=java.sql.Date.valueOf(ld);
				
				product.setManufactureDate(date);
				
				//send bean to service
				
				RequestDispatcher rd= null;
				
				
				try
				{
					int productId=productService.addProduct(product);
					
					request.setAttribute("id",productId);
					rd=request.getRequestDispatcher("AddProduct.jsp");
				}
				catch(ProductException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to add product details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				return;//return instead of break cuz forward is used
				
			case "ViewAll":
				
				rd=null;
				
				try
				{
					List<Product> products = productService.getProducts();
					
					request.setAttribute("products",products);
					
					rd=request.getRequestDispatcher("ViewAllProducts.jsp");
					
					
				}
				catch(ProductException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to add product details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
				return;
				
			case "FetchProduct":
				String idStr = request.getParameter("productId");
				
				try
				{
					product=productService.getProduct(Integer.parseInt(idStr));
					request.setAttribute("Product",product);
					rd=request.getRequestDispatcher("GetProduct.jsp");
				}
				catch(ProductException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to fetch product details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				//return;	
				
			case "RemoveProduct":
				idStr = request.getParameter("productId");
				
				try
				{
					product=productService.removeProduct(Integer.parseInt(idStr));
					request.setAttribute("Product",product);
					rd=request.getRequestDispatcher("RemoveProduct.jsp");
				}
				catch(ProductException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to remove product details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
			case "FetchProductForUpdate":
				idStr = request.getParameter("productId");
				
				try
				{
					product=productService.getProduct(Integer.parseInt(idStr));
					request.setAttribute("Product",product);
					rd=request.getRequestDispatcher("UpdateProduct.jsp");
				}
				catch(ProductException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to fetch product details for update..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
				return;
				
			case "updatePro":
				
				String id=request.getParameter("id");
				name=request.getParameter("name");
				price=request.getParameter("price");
				quantity=request.getParameter("quantity");
				category=request.getParameter("category");
				manufactureDate=request.getParameter("manufactureDate");
				
				//create a DTO form the form data read
				
				product=new Product();
				
				product.setId(Integer.parseInt(id));
				product.setName(name);
				product.setPrice(Double.parseDouble(price));
				product.setQuantity(Integer.parseInt(quantity));
				product.setCategory(category);
				
				
				//convert string to util date
				formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				ld= LocalDate.parse(manufactureDate,formatter);
				date=java.sql.Date.valueOf(ld);
				
				product.setManufactureDate(date);
				
				//send bean to service
				
				rd= null;
				
				
				try
				{
					productService.updateProduct(product);
					
					request.setAttribute("id", product.getId());
					rd=request.getRequestDispatcher("UpdateProduct.jsp");
				}
				catch(ProductException e)
				{
					request.setAttribute("errMsg", "Something went wrong while trying to updateing product details..Reason"+e.getMessage());
					rd=request.getRequestDispatcher("ErrorPage.jsp");
				}
				
				rd.forward(request, response);
				
				return;
				
			default:
				break;
			
		}
	}
	
}
