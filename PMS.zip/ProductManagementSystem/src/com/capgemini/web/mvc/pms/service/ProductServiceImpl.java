package com.capgemini.web.mvc.pms.service;

import java.util.List;

import com.capgemini.web.mvc.pms.dao.IProductDAO;
import com.capgemini.web.mvc.pms.dao.ProductDAOImpl;
import com.capgemini.web.mvc.pms.dto.Product;
import com.capgemini.web.mvc.pms.exception.ProductException;

public class ProductServiceImpl implements IProductService 
{
	
	private IProductDAO productDAO;
	public ProductServiceImpl()
	{
		//Association:loose coupling
		productDAO =  new ProductDAOImpl();
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		
		return productDAO.addProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		return productDAO.getProduct(id);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		productDAO.updateProduct(product);
	}

	@Override
	public Product removeProduct(int id) throws ProductException {
		return productDAO.removeProduct(id);
	}

	@Override
	public List<Product> getProducts() throws ProductException {
		return productDAO.getProducts();
	}

}
