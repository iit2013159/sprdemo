package com.capgemini.web.mvc.pms.dao;

import java.util.List;

import com.capgemini.web.mvc.pms.dto.Product;
import com.capgemini.web.mvc.pms.exception.ProductException;

public interface IProductDAO 
{
	public int addProduct(Product product) throws ProductException;
	
	public Product getProduct(int id) throws ProductException;
	
	public void updateProduct(Product product) throws ProductException;
	
	public Product removeProduct(int id) throws ProductException;
	
	public List<Product> getProducts() throws ProductException;

}
