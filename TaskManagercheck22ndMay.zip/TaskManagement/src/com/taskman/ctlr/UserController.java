package com.taskman.ctlr;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.taskman.dao.UserDao;
import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.User;


@Scope("session")
@Controller
@RequestMapping(value="user")
public class UserController {
	
	ArrayList<String> cityList;
	ArrayList<String> skillList;
	
	@Autowired
	UserDao allDao;
	
	@RequestMapping(value="/showLogin")
	public String prepareLogin(Model model)
	{
		System.out.println("In prepareLogin() method");
		model.addAttribute("login",new Login());
		return "login";
	}
	@RequestMapping(value="/createTask")
	public String createTask(@RequestParam("userId") String userId,Model model)
	{
		System.out.println("In create Task() method");
		model.addAttribute("userId",userId);
		model.addAttribute("task",new Task());
		model.addAttribute("users",allDao.fetchUsers());
		return "createTask";
	}
	@RequestMapping(value="/assignTask")
	public String assignTask(@RequestParam("pId") String assignedTo,@RequestParam("userId") String userId,Model model)
	{
		System.out.println("In assignTask() method");
		model.addAttribute("userId",userId);
		model.addAttribute("assignedTo",assignedTo);
		model.addAttribute("task",new Task());
		model.addAttribute("users",allDao.fetchUsers());
		return "createTask";
	}
	
	@RequestMapping(value="/showTask")
	public String showTask(Model model)
	{
		System.out.println("In showTask() method");
		System.out.println(allDao.fetchTask());
		List l = allDao.fetchTask();
		for(int j = 0; j < l.size();j++) {
			Map st = (Map) l.get(j);
			System.out.println(st.get("id"));
		}
		model.addAttribute("list",allDao.fetchTask());
		return "task";
	}
	@RequestMapping(value="/showContacts")
	public String showContacts(@RequestParam("pId") String userId,Model model)
	{
		System.out.println("In showContacts() method");
		System.out.println(allDao.fetchContacts());
		List l = allDao.fetchContacts();
		for(int j = 0; j < l.size();j++) {
			Map st = (Map) l.get(j);
			System.out.println(st.get("username"));
		}
		model.addAttribute("userId",userId);
		model.addAttribute("list",allDao.fetchContacts());
		return "showContacts";
	}
	
	@RequestMapping(value="/showTaskForU")
	public String showTaskForU(@RequestParam("userId") String userId,Model model)
	{
		System.out.println("In showTaskForU() method");
		System.out.println(allDao.fetchTask(userId));
		List l = allDao.fetchTask();
		for(int j = 0; j < l.size();j++) {
			Map st = (Map) l.get(j);
			System.out.println(st.get("id"));
		}
		model.addAttribute("list",allDao.fetchTask(userId));
		return "task";
	}
	
	@RequestMapping(value="/insertTask", method = RequestMethod.POST)
	public String insertTask(@ModelAttribute("task")@Valid Task task,BindingResult result,Model model)
	{
		String string = "In InsertTask method";
		System.out.println(string);
		 if(result.hasErrors())
		 {
			 
			 return "error";
		 }
		 
		  int itrSuccess=allDao.insertTask(task);
		  model.addAttribute("task",task);  
		  if(itrSuccess!=0)
		  {             		  
	  	     return "taskSuccess";
		  }
		  else
			 return "error";
	}
	
	@RequestMapping("/update")
	public String updateStatus(@RequestParam("pId") String pId,@RequestParam("status") String status,Model model){
		int itrSuccess=allDao.updateStatus(pId,status);
		return "updateSuccess";
	}
	
	@RequestMapping("/updateTask")
	public String loadUpdateTask(@ModelAttribute("task")@Valid Task task,@RequestParam("pId") String pId,@RequestParam("userId") String userId, Model model) {
		System.out.println("In assignTask() method");
		model.addAttribute("pId",pId);
		model.addAttribute("userId",userId);
		return "updateStatus";
	
	}
	
	@RequestMapping(value= "/logout")
	public String logout(HttpSession session){
		session.invalidate();
		return "login";
	}
	
	@RequestMapping(value="/checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login login,BindingResult result,Model model,HttpSession session)
	{
		
		if(session.isNew()){
		System.out.println("in checkLogin()");
		
		if(result.hasErrors())
			return "login";
		
		//Logic to validate userName and password against database
		System.out.println("Dao "+allDao);
		boolean userPresent=allDao.validate(login);
		model.addAttribute("user",login);
		
		if(userPresent)
	  	    return "loginSuccess";
		else
			return "loginFailed";
		}
		else{
			return "error";
		}
	}

	@RequestMapping(value="/showRegister")
	public String prepareRegister(Model model)
	{
		cityList =new ArrayList<String>();
		cityList.add("Pune");
		cityList.add("Mumbai");
		cityList.add("Bangalore");
		cityList.add("Chennai");
		cityList.add("Delhi");
		
		skillList =new ArrayList<String>();
		
		skillList.add("Java");
		skillList.add("Mainframe");
		skillList.add("ODS");
		skillList.add("Testing");
		
		model.addAttribute("cityList",cityList);
		model.addAttribute("skillList",skillList);
		
		model.addAttribute("user",new User());
	    return "register";	
	}
	
	@RequestMapping(value="/checkRegister")
	public String checkRegister(@ModelAttribute("user")@Valid User user,BindingResult result,Model model)
	{
		 if(result.hasErrors())
		 {
			 model.addAttribute("cityList",cityList);
    		 model.addAttribute("skillList",skillList);

			 return "register";
		 }
		 
		  int registerSuccess=allDao.insertRec(user);
		  if(registerSuccess!=0)
		  {
             model.addAttribute("user",user);  		  
	  	     return "registerSuccess";
		  }
		  else
			 return "registerFailed";
	}
	
	
	 
	

}
