package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.dao.AccountsDAO;
import com.capgemini.dto.AccountsDTO;



@Controller
@RequestMapping(value="bank")
public class BankController {
	
	@Autowired
	AccountsDAO accountsDAO;
	
	
	
	@RequestMapping(value="/customerMenu")
	public String customerMenu(Model model)
	{
		System.out.println("In checkCustomer() method");
		model.addAttribute("accountsDTO",new AccountsDTO());
		return "home";
	}
	
	@RequestMapping(value="/checkCustomer")
	public String checkCustomer(@ModelAttribute("accountsDTO") @Valid AccountsDTO accountsDTO,
			BindingResult result,Model model)
	{
		if(result.hasErrors())
			return "home";
		
		List<AccountsDTO> accountDetailsList=new ArrayList<AccountsDTO>();
		accountDetailsList= accountsDAO.getAccountDetails(accountsDTO);
		if(accountDetailsList.size()!=0)
		{
			
			model.addAttribute("accountDetailsList",accountDetailsList);
			model.addAttribute("custName",accountsDTO.getCustName());
			return "AccountInfo";
		}
		else
		{
			return "ErrorAccountInfo";
		}
	}

}
