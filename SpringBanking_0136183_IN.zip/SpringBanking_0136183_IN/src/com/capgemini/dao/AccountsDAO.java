package com.capgemini.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.capgemini.dto.AccountsDTO;

@Component("dao")
public class AccountsDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<AccountsDTO>getAccountDetails(AccountsDTO accountsDTO)
	{
		String sql=new String("select * from account_details "
				+ "where customer_name = "+accountsDTO.getCustName());
		 List<AccountsDTO>accountdetailsList=jdbcTemplate.query(sql,new RowMapper() {
			 
	            public AccountsDTO mapRow(ResultSet result, int rowNum) throws SQLException {
	                AccountsDTO accountsDTO = new AccountsDTO();
	                accountsDTO.setAccountNum(result.getString(1));
	                accountsDTO.setCustName(result.getString(2));
	                accountsDTO.setAccountType(result.getString(3));
	                accountsDTO.setAccountLoc(result.getString(4));
	                accountsDTO.setBalance(result.getDouble(5));
	                 
	                return accountsDTO;
	            }
	             
	        });
		return accountdetailsList;
	}

}
