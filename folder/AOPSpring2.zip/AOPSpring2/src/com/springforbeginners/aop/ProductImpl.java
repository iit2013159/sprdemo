package com.springforbeginners.aop;

public class ProductImpl implements Product {
    @Override
    public int multiply(int a, int b) {
        return a*b;
    }
}
