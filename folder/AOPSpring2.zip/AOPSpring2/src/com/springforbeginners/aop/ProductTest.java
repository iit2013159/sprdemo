package com.springforbeginners.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProductTest {
    public static void main(String args[]){
        ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
        Product product = (Product)context.getBean("product");
        int result = product.multiply(10,10);
        System.out.println("Result = " + result);

        result = product.multiply(0,0);
        //System.out.println("Result = " + result);        
    }
}
