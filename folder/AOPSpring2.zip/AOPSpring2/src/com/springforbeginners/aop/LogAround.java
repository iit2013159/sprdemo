package com.springforbeginners.aop;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class LogAround implements MethodInterceptor {
    @Override
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {
        Object arguments[] = methodInvocation.getArguments();
        int number1 = ((Integer)arguments[0]).intValue();
        int number2 = ((Integer)arguments[1]).intValue();
        
        if(number1 == 0 && number2 == 0) {
            throw new Exception("Cannot multiply 0 with 0.");
        }
        return methodInvocation.proceed();
    }
}
