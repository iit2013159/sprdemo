package com.springforbeginners.aop;

public interface Product {
    public int multiply(int a, int b);
}
