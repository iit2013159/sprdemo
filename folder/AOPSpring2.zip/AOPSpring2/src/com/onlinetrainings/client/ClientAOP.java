package com.onlinetrainings.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.onlinetrainings.service.Product;

public class ClientAOP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext appContext = new ClassPathXmlApplicationContext(
				"context.xml");

		Product product = (Product) appContext.getBean("productImpl");

		int result = product.multiply(10, 10);

		System.out.println(result);

		result = product.multiply(0, 0);
	}
}