package com.shashank;

public interface EmployeeInfo {
	public void printEmployee();
}
