package com.shashank;

public class Employee implements EmployeeInfo{
	private int empid;
	private Address address1;
	private String name;
	private float salary;
	
	public Employee(){
		
	}
	
	public Employee(int empid, Address address, String name, float salary) {
		super();
		this.empid = empid;
		this.address1 = address;
		this.name = name;
		this.salary = salary;
	}

	public int getEmpid() {
		return empid;
	}
	
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public float getSalary() {
		return salary;
	}
	
	
	public Address getAddress1() {
		return address1;
	}

	public void setAddress1(Address address) {
		this.address1 = address;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public static Employee getInstance(){
		return new Employee();
	}
	@Override
	public void printEmployee() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: " + empid);
		System.out.println("Name: " + name);
		System.out.println("Address: " + address1);
		System.out.println("Salary: " + salary);
	}
	
	
}