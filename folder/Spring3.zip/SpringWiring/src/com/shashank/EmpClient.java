package com.shashank;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");

		EmployeeInfo ei = (EmployeeInfo)appContext.getBean("emp");
		ei.printEmployee();
		
	/*	ei = (EmployeeInfo)appContext.getBean("emp1");
		ei.printEmployee();
		
		ei = (EmployeeInfo)appContext.getBean("emp2");
		ei.printEmployee();*/
	}
}