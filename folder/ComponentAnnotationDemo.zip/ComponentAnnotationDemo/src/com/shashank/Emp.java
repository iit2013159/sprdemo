package com.shashank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("employee")
public class Emp implements EmpInterface {

	private int empid;
	private String name;
	
	@Autowired
	private Date dob;
	
	private Date doj;
	
	@Autowired
	private Address address;
	private float salary;
	
	public Emp(){
		empid=15;
		name="xyz";
		salary=100000;
	}
	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getName() {
		return name;
	}

	
	public void setName(String name) {
		this.name = name;
	}


	public Date getDob() {
		return dob;
	}

	
	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getDoj() {
		return doj;
	}
	
	
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	@Override
	public void printIt() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: " + empid);
		System.out.println("Employee name: " + name);
		System.out.println("Date of Birth: " + dob);
		System.out.println("Date of Joining: " + doj);		
		System.out.println("Address: " + address);
		System.out.println("Salary: " + salary);
	}
}