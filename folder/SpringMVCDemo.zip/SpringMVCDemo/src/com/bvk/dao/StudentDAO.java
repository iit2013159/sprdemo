package com.bvk.dao;

import java.sql.SQLException;

import com.bvk.entity.StudentTO;

public interface StudentDAO {
	public int insertStudent(StudentTO studentTO) throws ClassNotFoundException, SQLException;
}