package com.bvk.entity;

public class StudentTO {
	private int rollNo;
	private String name;
	private int m1;
	private int m2;
	private int total;
	private float percent;
	
	public StudentTO() {
		super();
	}

	public StudentTO(int rollNo, String name, int m1, int m2) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.m1 = m1;
		this.m2 = m2;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getM1() {
		return m1;
	}

	public void setM1(int m1) {
		this.m1 = m1;
	}

	public int getM2() {
		return m2;
	}

	public void setM2(int m2) {
		this.m2 = m2;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}

	@Override
	public String toString() {
		return "rollNo=" + rollNo + "\nname=" + name + "\nm1=" + m1 + "\nm2=" + m2 + "\ntotal=" + total + "\npercent="
				+ percent + "\n==============================================================";
	}
}