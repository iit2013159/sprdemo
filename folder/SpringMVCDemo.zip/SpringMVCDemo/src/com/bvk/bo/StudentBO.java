package com.bvk.bo;

import com.bvk.entity.StudentTO;

public interface StudentBO {
	public String calculate(StudentTO studentTO);
}