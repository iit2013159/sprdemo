package com.bvk.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.bvk.entity.CustomerTO;

public class ClientDBOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice = 1;
		
		int custId = 0;
		String name = null;
		String address = null;
		
		CustomerTO customerTO = null;
		
		Scanner scCustomer = new Scanner(System.in);
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		List<CustomerTO>customers = null;
		
		HibernateTemplate hibernateTemplate = (HibernateTemplate)appContext.getBean("hibernateTemplate");
		Outer:
		while(choice != 0){
			System.out.println("Following is the choice:");
			System.out.println("1. Insert");
			System.out.println("2. Update");
			System.out.println("3. Delete");
			System.out.println("4. View");
			System.out.println("0. Exit");
			
			choice = Integer.parseInt(scCustomer.nextLine());
			
			switch(choice){
			case 1:
				System.out.print("Enter Customer ID: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				System.out.print("Enter Customer Name: ");
				name = scCustomer.nextLine();
				
				System.out.print("Enter Customer Address: ");
				address = scCustomer.nextLine();
				
				customerTO = new CustomerTO(custId, name, address);
				hibernateTemplate.save(customerTO);
				System.out.println("Record inserted");
				break;
			case 2:
				System.out.print("Enter Customer ID: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				System.out.print("Enter Customer Name: ");
				name = scCustomer.nextLine();
				
				System.out.print("Enter Customer Address: ");
				address = scCustomer.nextLine();
				
				customerTO = new CustomerTO(custId, name, address);
				hibernateTemplate.update(customerTO);
				System.out.println("Record updated");
				break;
			case 3:
				System.out.print("Enter Customer ID of the record to be deleted: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				customerTO = new CustomerTO(custId, name, address);
				hibernateTemplate.delete(customerTO);
				System.out.println("Record deleted");
				break;
			case 4:
				customers = (List<CustomerTO>)hibernateTemplate.find("from CustomerTO");
				for (CustomerTO customer : customers) {
					System.out.println(customer);
				}
				break;
			case 0:
				break Outer;
				default:
					break;
			}
		}
	}
}