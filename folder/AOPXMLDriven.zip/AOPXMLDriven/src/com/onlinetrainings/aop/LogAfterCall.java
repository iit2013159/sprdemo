package com.onlinetrainings.aop;

import org.aspectj.lang.JoinPoint;

public class LogAfterCall {

	public void logAfter(JoinPoint joinPoint) {
		System.out.println("After calling the method...");
	}
}
