package com.onlinetrainings.aop;

import org.aspectj.lang.JoinPoint;

public class LogBeforeCall {

	public void logBefore(JoinPoint joinPoint) {
		System.out.println("Before calling the method...");
	}
}
