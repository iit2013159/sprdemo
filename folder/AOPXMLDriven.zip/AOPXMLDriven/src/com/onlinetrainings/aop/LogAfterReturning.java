package com.onlinetrainings.aop;

import org.aspectj.lang.JoinPoint;

public class LogAfterReturning {

	public void afterReturning(JoinPoint joinPoint, Object result)
			throws Throwable {
		System.out.println("After normal return from Method: " + result);
	}
}
