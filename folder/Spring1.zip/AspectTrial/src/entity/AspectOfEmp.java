package entity;

import org.aspectj.lang.JoinPoint;

import org.aspectj.lang.annotation.After;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class AspectOfEmp {
	@Before("execution(* entity.Employee.*(..))")
	public void messageBefore(JoinPoint jp){
		System.out.println("Before calculation");
		System.out.println(jp.getKind());
		System.out.println(jp.getArgs());
	}
	
	@After("execution(* entity.Employee.*(..))")
	public void messageAfter(){
		System.out.println("After calculation");
	}
}