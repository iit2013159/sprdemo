package entity;

public class Employee {
	private int empid;
	private String name;
	private float basic;
	private float da;
	private float hra;
	private float pf;
	private float salary;
	
	public Employee(){
		
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getBasic() {
		return basic;
	}

	public void setBasic(float basic) {
		this.basic = basic;
	}

	public float getDa() {
		return da;
	}

	public void setDa(float da) {
		this.da = da;
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}

	public float getPf() {
		return pf;
	}

	public void setPf(float pf) {
		this.pf = pf;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public void calcSal(){
		salary = basic + da + hra - pf;
		System.out.println("Inside calcSal");
	}
	@Override
	public String toString() {
		return "empid="
				+ empid
				+ "\nname="
				+ name
				+ "\nbasic="
				+ basic
				+ "\nda="
				+ da
				+ "\nhra="
				+ hra
				+ "\npf="
				+ pf
				+ "\nsalary="
				+ salary
				+ "\n==============================================================";
	}
	
	
}