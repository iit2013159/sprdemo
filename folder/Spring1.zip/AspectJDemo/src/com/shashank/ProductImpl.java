package com.shashank;

public class ProductImpl implements Product {

	@Override
	public int multiply(int a, int b) {
		// TODO Auto-generated method stub
		return a*b;
	}

}
