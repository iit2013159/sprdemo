package com.shashank;

public interface Product {
	public int multiply(int a, int b);
}
