package com.shashank;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LogAround {
	@Around("execution(* com.shashank.Product.multiply(..))")
  //@Around("execution(* com.shashank.Product.multiply(..))")
	public Object invoke(ProceedingJoinPoint joinPoint) throws Throwable{
		Object arguments[] = joinPoint.getArgs();
		
		int num1 = ((Integer)arguments[0]).intValue();
		int num2 = ((Integer)arguments[1]).intValue();
		
		if(num1 == 0 || num2 == 0){
			throw new Exception("Cannot multiply 0 with 0");
		}
		return joinPoint.proceed();
	}
}
