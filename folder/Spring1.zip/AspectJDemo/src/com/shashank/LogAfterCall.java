package com.shashank;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LogAfterCall {
	@After("execution(* com.shashank.Product.multiply(..))")
 //@After("execution(* com.shashank.Product.multiply(..))")
	public void logAfter(){
		System.out.println("After calling the method");
	}
}
