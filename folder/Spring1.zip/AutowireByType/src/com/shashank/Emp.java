package com.shashank;

import org.springframework.beans.factory.annotation.Autowired;

public class Emp implements EmpInterface {

	private int empid;
	private String name;
	private Date dob;
	private Address address;
	private float salary;
	
	
	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getDob() {
		return dob;
	}

	@Autowired//(required=false)
	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Address getAddress() {
		return address;
	}

	@Autowired
	public void setAddress(Address address) {
		this.address = address;
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	@Override
	public void printIt() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: " + empid);
		System.out.println("Employee name: " + name);
		System.out.println("Date of Birth: " + dob);
		System.out.println("Address: " + address);
		System.out.println("Salary: " + salary);
	}
}