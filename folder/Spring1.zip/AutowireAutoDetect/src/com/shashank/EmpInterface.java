package com.shashank;

public interface EmpInterface {
		public void printIt();
}
