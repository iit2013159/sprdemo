package com.shashank;

public class Emp implements EmpInterface {

	private int empid;
	private String name;
	private Date dob;
	private Address address;
	private float salary;
	
	public Emp(){
		empid=10;
		name = "Kakarao";
		salary = 400000;
		System.out.println("In default constructor of emp");
	}
	
	public Emp(int empid, String name, Date dob, Address address, float salary) {
//		super();
		this.empid = empid;
		this.name = name;
		this.dob = dob;
		this.address = address;
		this.salary = salary;
		System.out.println("In parameterized constructor");
	}
	
	public Emp(Date dob, Address address) {
	//	super();
		this.empid = 55;
		this.name = "Amar";
		this.dob = dob;
		this.address = address;
		this.salary = 66000;
		System.out.println("In specific constructor");
	}
	
	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	@Override
	public void printIt() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: " + empid);
		System.out.println("Employee name: " + name);
		System.out.println("Date of Birth: " + dob);
		System.out.println("Address: " + address);
		System.out.println("Salary: " + salary);
	}
}