package com.javalearning.entity;

import java.util.LinkedHashSet;

public class Employee {
	private int empid;
	private String name;
	private float salary;
	private LinkedHashSet<String>certifications;
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Employee(int empid, String name, float salary,
			LinkedHashSet<String> certifications) {
		super();
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		this.certifications = certifications;
	}


	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	public LinkedHashSet<String> getCertifications() {
		return certifications;
	}


	public void setCertifications(LinkedHashSet<String> certifications) {
		this.certifications = certifications;
	}


	@Override
	public String toString() {
		return "empid="
				+ empid
				+ "\nname="
				+ name
				+ "\nsalary="
				+ salary
				+ "\ncertifications="
				+ certifications
				+ "\n==============================================================";
	}	
}