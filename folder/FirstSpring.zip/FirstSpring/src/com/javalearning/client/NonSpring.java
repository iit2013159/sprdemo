package com.javalearning.client;

import com.javalearning.entity.Arith;
import com.javalearning.entity.SecondArith;

public class NonSpring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arith arith = new SecondArith();
		
		System.out.println(arith.add(10, 20));
	}
}