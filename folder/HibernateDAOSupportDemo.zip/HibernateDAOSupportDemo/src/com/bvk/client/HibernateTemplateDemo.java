package com.bvk.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.bvk.entity.Employee;

public class HibernateTemplateDemo {
	public static void main(String[] args) {
		Employee employee = new Employee(88, "Rohit", 300000);
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		HibernateTemplate template = (HibernateTemplate)appContext.getBean("template");
		
		template.save(employee);
	}
}