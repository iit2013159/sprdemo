package com.bvk.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bvk.dao.EmployeeDAO;
import com.bvk.entity.Employee;

public class HibernateDAOSupportDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee(4, "svk", 75000);
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		EmployeeDAO employeeDAO = (EmployeeDAO)appContext.getBean("empDAO");
		
		employeeDAO.saveEmployee(employee);
		
		List<Employee>listEmployee = employeeDAO.findEmployees();
		
		for (Employee empl : listEmployee) {
			System.out.println(empl);
		}
	}
}