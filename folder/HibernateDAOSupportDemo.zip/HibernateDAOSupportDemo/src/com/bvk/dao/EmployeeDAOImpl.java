package com.bvk.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.bvk.entity.Employee;

public class EmployeeDAOImpl extends HibernateDaoSupport implements EmployeeDAO {

	@Transactional(readOnly=true)
	public List<Employee> findEmployees() {
		// TODO Auto-generated method stub
		List<Employee> empList = (List<Employee>)getHibernateTemplate().find("from Employee where name = ?)", "bvk");
        System.out.println("Employees found: " + empList.size());
        return empList;
	}

    @Transactional(readOnly=false)
    public void saveEmployee(Employee emp){
        System.out.println("Create new employee " + emp);
        getHibernateTemplate().save(emp);
        System.out.println("Employee created " + emp);        
    }
}