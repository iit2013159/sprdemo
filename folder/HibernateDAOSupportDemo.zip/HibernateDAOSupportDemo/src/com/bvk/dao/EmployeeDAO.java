package com.bvk.dao;

import java.util.List;

import com.bvk.entity.Employee;

public interface EmployeeDAO {
	List<Employee> findEmployees();
	 
    void saveEmployee(Employee employee);
}