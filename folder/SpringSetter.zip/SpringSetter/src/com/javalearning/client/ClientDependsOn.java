package com.javalearning.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javalearning.entity.Emp;

public class ClientDependsOn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		Emp emp = (Emp)appContext.getBean("empl");
		
		emp.calculateSalary();
		
		System.out.println(emp);
		/*A a = (A)appContext.getBean("testA");
		A a1 = (A)appContext.getBean("testA");
		
		if(a == a1){
			System.out.println("Singleton");
		}else{
			System.out.println("Prototype");
		}*/
		
	}
}