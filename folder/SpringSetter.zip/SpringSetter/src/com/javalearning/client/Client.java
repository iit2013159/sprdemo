package com.javalearning.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		/*SampleEntity se = (SampleEntity)appContext.getBean("se");
		System.out.println(se);*/
		/*Emp e = (Emp)appContext.getBean("emp");
		
		e.calculateSalary();*/
		
		/*SampleEntity se = (SampleEntity)appContext.getBean("se");
		
		System.out.println(se);*/
		//System.out.println(e);
		
		/*Address address = (Address)appContext.getBean("address");
		
		System.out.println(address);*/
		System.out.println("End of program");
	}
}