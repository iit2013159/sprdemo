package com.javalearning.entity;

public class B {
	public B(){
		System.out.println("Inside B");
	}
}