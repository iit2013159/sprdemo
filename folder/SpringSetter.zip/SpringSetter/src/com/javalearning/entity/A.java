package com.javalearning.entity;

public class A {
	public A(){
		System.out.println("Inside A");
	}
}