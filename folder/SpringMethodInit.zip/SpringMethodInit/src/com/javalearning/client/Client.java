package com.javalearning.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javalearning.entity.Emp;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		//Emp e = (Emp)appContext.getBean("emp");
		Emp e1 = (Emp)appContext.getBean("employee");
		
		System.out.println(e1);
		//System.out.println(e1);
		//Emp e1 = (Emp)appContext.getBean("empl");
		/*EmployeeInt ei = (EmployeeInt)appContext.getBean("employee");*/
		
		/*e.calculateSalary();
		System.out.println(e);*/
		
		/*if(e == e1){
			System.out.println("Singleton");
		}else{
			System.out.println("Prototype");
		}*/
		/*ei.calculateSalary();
		System.out.println(ei);*/
		((AbstractApplicationContext) appContext).registerShutdownHook();
	}

}
