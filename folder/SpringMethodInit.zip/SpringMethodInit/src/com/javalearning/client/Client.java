package com.javalearning.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javalearning.entity.Employee;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		//Emp e = (Emp)appContext.getBean("empl");
		Employee e = (Employee)appContext.getBean("empl");
		e.calculateSalary();
		System.out.println(e);
		
		//appContext.registerShutdownHook();
	}

}
