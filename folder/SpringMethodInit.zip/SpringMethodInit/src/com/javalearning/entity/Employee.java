package com.javalearning.entity;

import org.springframework.stereotype.Component;

@Component("emp")
public class Employee implements Emp{
	private int empid;
	private String name;
	private int basic;
	private float da;
	private float hra;
	private float pf;
	private float salary;
	
	
	public Employee() {
		super();
	}

	public Employee(int empid, String name, int basic, float da, float hra,
			float pf) {
		super();
		this.empid = empid;
		this.name = name;
		this.basic = basic;
		this.da = da;
		this.hra = hra;
		this.pf = pf;
	}

	public static Employee initBean(){
		Employee e = new Employee(1, "bvk", 100000, 20000, 10000, 5000);
		
		e.salary = e.basic + e.da + e.hra - e.pf;
		
		System.out.println("Resources initialized in static method...");
		
		return e;
	}
	//@PostConstruct //init-method
	public void init(){
		this.empid = 10;
		this.name = "Bhalchandra";
		this.basic = 80000;
		this.da = 20000;
		this.hra = 10000;
		this.pf = 5000;
		this.salary = this.basic + this.da + this.hra - this.pf;
		System.out.println("Resources initialized in Employee");
	}
	
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBasic() {
		return basic;
	}

	public void setBasic(int basic) {
		this.basic = basic;
	}

	public float getDa() {
		return da;
	}

	public void setDa(float da) {
		this.da = da;
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public float getPf() {
		return pf;
	}

	public void setPf(float pf) {
		this.pf = pf;
	}

	@Override
	public void calculateSalary() {
		// TODO Auto-generated method stub
		salary = basic + da + hra - pf;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", basic="
				+ basic + ", da=" + da + ", hra=" + hra + ", pf=" + pf
				+ ", salary=" + salary + "]";
	}
	
	//@PreDestroy //destroy
	public void destroy(){
		this.name = null;
		System.out.println("Resources released in Employee");
	}

	/*@Override
	public void afterPropertiesSet() throws Exception {
		this.empid = 10;
		this.name = "Bhalchandra";
		this.basic = 80000;
		this.da = 20000;
		this.hra = 10000;
		this.pf = 5000;
		this.salary = this.basic + this.da + this.hra - this.pf;
		System.out.println("After Properties Set.");
		
	}*/

}