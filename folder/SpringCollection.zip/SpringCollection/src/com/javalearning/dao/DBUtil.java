package com.javalearning.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	private Properties prop;

	public Properties getProp() {
		return prop;
	}

	public void setProp(Properties prop) {
		this.prop = prop;
	}

	public Connection createConnection() throws ClassNotFoundException,
			SQLException {
		Connection connStudent;
				
		String url = prop.getProperty("url");
		String username = prop.getProperty("username");
		String password = prop.getProperty("password");
		String driver = prop.getProperty("driver");
		
		Class.forName(driver);

		connStudent = DriverManager.getConnection(url, username, password);

		System.out.println("Connection established");
		return connStudent;
	}

	
}