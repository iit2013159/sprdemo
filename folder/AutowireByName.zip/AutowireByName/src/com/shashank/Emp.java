package com.shashank;

public class Emp implements EmpInterface {

	private int empid;
	private String name;
	private Date dob1;
	private Address add1;
	private float salary;
	
	
	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getDob1() {
		return dob1;
	}

	
	public void setDob1(Date dob) {
		this.dob1 = dob;
		System.out.println("Date Set");
	}


	public Address getAdd1() {
		return add1;
	}

	
	public void setAdd1(Address add1) {
		this.add1= add1;
		System.out.println("Address Set");
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	@Override
	public void printIt() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: " + empid);
		System.out.println("Employee name: " + name);
		System.out.println("Date of Birth: " + dob1);
		System.out.println("Address: " + add1);
		System.out.println("Salary: " + salary);
	}
}