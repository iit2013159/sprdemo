package com.taskman.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.TaskDetails;
import com.taskman.dto.User;

@Component("dao")
public class UserDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public boolean validate(Login login)
	{
		boolean userPresent=false;

		String sql = "SELECT count(*) from Login414 where username=? AND password=?";
		int count=(int)jdbcTemplate.queryForInt(sql,login.getUserName(),login.getPassword());
		if(count==1)
			userPresent=true;
		else
			userPresent=false;		

		return userPresent;
	}
	
	public int insertRec(User user)
	{
		String skills="";
		for(String skl:user.getSkillSet())
		{
			skills=skills+skl+" ";
		}
		skills=skills.trim();

		String sql1="insert into user414 values(?,?,?,?,?,?)";
		Object[] params=new Object[]{user.getUserName(),Character.toString(user.getGender()),user.getEmail(),skills,user.getCity(),user.getPhone()};
		jdbcTemplate.update(sql1,params);

		String sql2="insert into login414 values(?,?)";
		params=new Object[]{user.getUserName(),user.getPassword()};
		return jdbcTemplate.update(sql2, params);

	}
	public List fetchContacts(){
		String query ="select username,phone from user414";
		return jdbcTemplate.queryForList(query);
	}
	public int updateStatus(String pId,String status,String userId){
		if(status.matches("done")){
			String query=  "update task set status = '" +status+ "' "+",updationHistory =concat(updationHistory, '"+"Completed by "+userId +"at "+new Date()+"'),enddate ="+ new java.sql.Timestamp((new Date()).getTime())+"where id = '"+pId+"'";
			//String updateQuery = "update task set status = '" +status+ "' where id = '"+pId+"'";
			return jdbcTemplate.update(query);
		}
		String query=  "update task set status = '" +status+ "' "+",updationHistory =concat(updationHistory, '"+"updated by "+userId +"at "+new Date()+"')"+"where id = '"+pId+"'";
		//String updateQuery = "update task set status = '" +status+ "' where id = '"+pId+"'";
		return jdbcTemplate.update(query);		
	}
	public List fetchUsers(){
		String query = "select username from login414";
		return jdbcTemplate.query(query, new RowMapper<String>(){
            public String mapRow(ResultSet rs, int rowNum) 
                    throws SQLException {
							return rs.getString(1);
							}
            });
	}
	public List fetchTask(){
		return jdbcTemplate.queryForList("SELECT *from task");
	}
	public List fetchTask(String id){
		return jdbcTemplate.queryForList("SELECT *from task where assignedto ='"+id+"'");
	}
	public Task fetchtask(String taskId){
		return null;
	}
	public int insertTask(Task task){
		String query = "insert into task values(?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] params = new Object[]{
				task.getId(),
				task.getName(),
				task.getDetails(),
				new Date(),
				new Date(),
				task.getStatus(),
				task.getPriority(),
				task.getoffshoreOwner(),
				task.getOnshoreOwner(),
				task.getAssignedBy(),
				task.getAssignedTo(),
				task.getUpdationHistory()
				};
		return jdbcTemplate.update(query, params);
	}
	
	public int insertTask(TaskDetails task){
		String query = "insert into taskdetails values(?,?,?,?,?,?,?,?)";
		Object[] params = new Object[]{task.getTaskId(),task.getTaskName(),task.getTaskDetails(),new java.sql.Timestamp(task.getStartDate().getTime()),new java.sql.Timestamp(task.getEndDate().getTime()),task.getPriority(),task.getOffshoreOwner(),task.getOnshoreOwner()};
		return jdbcTemplate.update(query, params);
	}
}
