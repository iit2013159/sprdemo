package com.taskman.dto;

import java.util.Date;

public class TaskDetails {
	String taskId;
	String taskName;
	String taskDetails;
	Date startDate;
	Date endDate;
	String priority;
	String offshoreOwner;
	String onshoreOwner;
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskDetails() {
		return taskDetails;
	}
	public void setTaskDetails(String taskDetails) {
		this.taskDetails = taskDetails;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getOffshoreOwner() {
		return offshoreOwner;
	}
	public void setOffshoreOwner(String offshoreOwner) {
		this.offshoreOwner = offshoreOwner;
	}
	public String getOnshoreOwner() {
		return onshoreOwner;
	}
	public void setOnshoreOwner(String onshoreOwner) {
		this.onshoreOwner = onshoreOwner;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + ((offshoreOwner == null) ? 0 : offshoreOwner.hashCode());
		result = prime * result + ((onshoreOwner == null) ? 0 : onshoreOwner.hashCode());
		result = prime * result + ((priority == null) ? 0 : priority.hashCode());
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((taskDetails == null) ? 0 : taskDetails.hashCode());
		result = prime * result + ((taskId == null) ? 0 : taskId.hashCode());
		result = prime * result + ((taskName == null) ? 0 : taskName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskDetails other = (TaskDetails) obj;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (offshoreOwner == null) {
			if (other.offshoreOwner != null)
				return false;
		} else if (!offshoreOwner.equals(other.offshoreOwner))
			return false;
		if (onshoreOwner == null) {
			if (other.onshoreOwner != null)
				return false;
		} else if (!onshoreOwner.equals(other.onshoreOwner))
			return false;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (taskDetails == null) {
			if (other.taskDetails != null)
				return false;
		} else if (!taskDetails.equals(other.taskDetails))
			return false;
		if (taskId == null) {
			if (other.taskId != null)
				return false;
		} else if (!taskId.equals(other.taskId))
			return false;
		if (taskName == null) {
			if (other.taskName != null)
				return false;
		} else if (!taskName.equals(other.taskName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TaskDetails [taskId=" + taskId + ", taskName=" + taskName + ", taskDetails=" + taskDetails
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", priority=" + priority + ", offshoreOwner="
				+ offshoreOwner + ", onshoreOwner=" + onshoreOwner + "]";
	}

}
