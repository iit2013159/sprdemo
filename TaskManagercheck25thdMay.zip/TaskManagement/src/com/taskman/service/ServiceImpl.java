package com.taskman.service;

import java.util.List;

import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.User;
import com.taskman.exception.ApplicationException;

public class ServiceImpl implements Service {

	@Override
	public boolean validate(Login login) throws ApplicationException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int insertRec(User user) throws ApplicationException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List fetchContacts() throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateStatus(String pId, String status, String userId) throws ApplicationException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List fetchUsers() throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List fetchTask() throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List fetchTask(String id) throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Task fetchtask(String taskId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insertTask(Task task) throws ApplicationException {
		// TODO Auto-generated method stub
		return 0;
	}

}
