package com.taskman.dao;

import java.util.List;

import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.User;
import com.taskman.exception.ApplicationException;

public interface UserDataAccess {

	
	/**
	 * @param login
	 * @return
	 * @throws ApplicationException
	 */
	boolean validate(Login login) throws ApplicationException;

	/**
	 * 
	 * @param user
	 * @return
	 * @throws ApplicationException 
	 */
	int insertRec(User user) throws ApplicationException;

	/**
	 * @return
	 * @throws ApplicationException 
	 */
	List fetchContacts() throws ApplicationException;

	/**
	 * @param pId
	 * @param status
	 * @param userId
	 * @return
	 * @throws ApplicationException 
	 */
	int updateStatus(String pId, String status, String userId) throws ApplicationException;

	/**
	 * @return
	 * @throws ApplicationException 
	 */
	List fetchUsers() throws ApplicationException;

	/**
	 * @return
	 * @throws ApplicationException 
	 */
	List fetchTask() throws ApplicationException;

	/**
	 * @param id
	 * @return
	 * @throws ApplicationException 
	 */
	List fetchTask(String id) throws ApplicationException;

	/**
	 * @param taskId
	 * @return
	 */
	Task fetchtask(String taskId);

	/**
	 * @param task
	 * @return
	 * @throws ApplicationException 
	 */
	int insertTask(Task task) throws ApplicationException;

}