package com.taskman.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.taskman.dto.Login;
import com.taskman.dto.Task;
import com.taskman.dto.User;
import com.taskman.exception.ApplicationException;

@Component("userDao")
public class UserDao implements UserDataAccess {

	@Autowired
	JdbcTemplate jdbcTemplate;

	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#validate(com.taskman.dto.Login)
	 */
	@Override
	public boolean validate(Login login) throws ApplicationException
	{
		try {
			boolean userPresent=false;

			String sql = Messages.getString("UserDao.QuerytoCheckLogin"); //$NON-NLS-1$
			int count=(int)jdbcTemplate.queryForInt(sql,login.getUserName(),login.getPassword());
			if(count==1)
				userPresent=true;
			else
				userPresent=false;		

			return userPresent;
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in Validation");
		}
	}
	
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#insertRec(com.taskman.dto.User)
	 */
	@Override
	public int insertRec(User user) throws ApplicationException
	{
		try {
			String skills = test(user);

			String sql1=Messages.getString("UserDao.insertIntoUserTable"); //$NON-NLS-1$
			Object[] params=new Object[]{user.getUserName(),Character.toString(user.getGender()),user.getEmail(),skills,user.getCity(),user.getPhone()};
			jdbcTemplate.update(sql1,params);

			String sql2=Messages.getString("UserDao.InsertintoLoginTable"); //$NON-NLS-1$
			params=new Object[]{user.getUserName(),user.getPassword()};
			return jdbcTemplate.update(sql2, params);
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in inserting");
			
		}

	}

	private String test(User user) {
		String skills=Messages.getString("UserDao.1"); //$NON-NLS-1$
		for(String skl:user.getSkillSet())
		{
			skills=skills+skl+Messages.getString("UserDao.2"); //$NON-NLS-1$
		}
		skills=skills.trim();
		return skills;
	}
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#fetchContacts()
	 */
	@Override
	public List fetchContacts() throws ApplicationException{
		try {
			String query =Messages.getString("UserDao.SelectUsernameAndPhoneFromUser"); //$NON-NLS-1$
			return jdbcTemplate.queryForList(query);
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in fetching Contacts");
		}
	}
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#updateStatus(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public int updateStatus(String pId,String status,String userId) throws ApplicationException{
		try {
			if(status.matches(Messages.getString("UserDao.Done"))){ //$NON-NLS-1$
				String query=  Messages.getString("UserDao.UpdateTaskSetStatus") +status+ Messages.getString("UserDao.InvertedComma")+Messages.getString("UserDao.UpdationHistory")+Messages.getString("UserDao.CompletedBy")+userId +Messages.getString("UserDao.at")+new Date()+Messages.getString("UserDao.enddate")+ new java.sql.Timestamp((new Date()).getTime())+Messages.getString("UserDao.whereId")+pId+Messages.getString("UserDao.InvertedCom"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
				//String updateQuery = "update task set status = '" +status+ "' where id = '"+pId+"'";
				return jdbcTemplate.update(query);
			}
			String query=  Messages.getString("UserDao.update") +status+ Messages.getString("UserDao.invertedComm")+Messages.getString("UserDao.updationHistoryAsConcatenated")+Messages.getString("UserDao.updatedBy")+userId +Messages.getString("UserDao.at")+new Date()+Messages.getString("UserDao.closingbracket")+Messages.getString("UserDao.whereId")+pId+Messages.getString("UserDao.invertedComma"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
			//String updateQuery = "update task set status = '" +status+ "' where id = '"+pId+"'";
			return jdbcTemplate.update(query);
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in Updating Status");
		}		
	}
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#fetchUsers()
	 */
	@Override
	public List fetchUsers() throws ApplicationException{
		try {
			String query = Messages.getString("UserDao.selectUsernameFromLogin"); //$NON-NLS-1$
			return jdbcTemplate.query(query, new RowMapper<String>(){
			    public String mapRow(ResultSet rs, int rowNum) 
			            throws SQLException {
								return rs.getString(1);
								}
			    });
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in fetching user");
		}
	}
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#fetchTask()
	 */
	@Override
	public List fetchTask()throws ApplicationException{
		try {
			return jdbcTemplate.queryForList(Messages.getString("UserDao.SelectAllFromTask")); //$NON-NLS-1$
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in fetching Task");
		}
	}
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#fetchTask(java.lang.String)
	 */
	@Override
	public List fetchTask(String id)throws ApplicationException{
		try {
			return jdbcTemplate.queryForList(Messages.getString("UserDao.SelectAllFromTaskWhereAssignedTo")+id+Messages.getString("UserDao.invertedComma")); //$NON-NLS-1$ //$NON-NLS-2$
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in fetching task");
		}
	}
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#fetchtask(java.lang.String)
	 */
	@Override
	public Task fetchtask(String taskId){
		return null;
	}
	/* (non-Javadoc)
	 * @see com.taskman.dao.UserDataAccess#insertTask(com.taskman.dto.Task)
	 */
	@Override
	public int insertTask(Task task)throws ApplicationException{
		try {
			String query = Messages.getString("UserDao.insertIntoTask"); //$NON-NLS-1$
			Object[] params = new Object[]{
					task.getId(),
					task.getName(),
					task.getDetails(),
					new Date(),
					new Date(),
					task.getStatus(),
					task.getPriority(),
					task.getoffshoreOwner(),
					task.getOnshoreOwner(),
					task.getAssignedBy(),
					task.getAssignedTo(),
					task.getUpdationHistory()
					};
			return jdbcTemplate.update(query, params);
		} catch (DataAccessException e) {
			throw new ApplicationException("Error occured in inserting Task");
		}
	}
	
}
