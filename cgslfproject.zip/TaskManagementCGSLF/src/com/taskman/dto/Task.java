package com.taskman.dto;

import java.util.Date;

public class Task {
	String id;
	String name;
	String details;
	Date startDate;
	Date endDate;
	String status;
	String priority;
	String OffshoreOwner;
	String onshoreOwner;
	String assignedBy;
	String assignedTo;
	String updationHistory;
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Task [id=" + id + ", name=" + name + ", details=" + details + ", startDate=" + startDate + ", endDate="
				+ endDate + ", status=" + status + ", priority=" + priority + ", OffshoreOwner=" + OffshoreOwner
				+ ", onshoreOwner=" + onshoreOwner + ", assignedBy=" + assignedBy + ", assignedTo=" + assignedTo
				+ ", updationHistory=" + updationHistory + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((OffshoreOwner == null) ? 0 : OffshoreOwner.hashCode());
		result = prime * result + ((assignedBy == null) ? 0 : assignedBy.hashCode());
		result = prime * result + ((assignedTo == null) ? 0 : assignedTo.hashCode());
		result = prime * result + ((details == null) ? 0 : details.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((onshoreOwner == null) ? 0 : onshoreOwner.hashCode());
		result = prime * result + ((priority == null) ? 0 : priority.hashCode());
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((updationHistory == null) ? 0 : updationHistory.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Task other = (Task) obj;
		if (OffshoreOwner == null) {
			if (other.OffshoreOwner != null)
				return false;
		} else if (!OffshoreOwner.equals(other.OffshoreOwner))
			return false;
		if (assignedBy == null) {
			if (other.assignedBy != null)
				return false;
		} else if (!assignedBy.equals(other.assignedBy))
			return false;
		if (assignedTo == null) {
			if (other.assignedTo != null)
				return false;
		} else if (!assignedTo.equals(other.assignedTo))
			return false;
		if (details == null) {
			if (other.details != null)
				return false;
		} else if (!details.equals(other.details))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (onshoreOwner == null) {
			if (other.onshoreOwner != null)
				return false;
		} else if (!onshoreOwner.equals(other.onshoreOwner))
			return false;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (updationHistory == null) {
			if (other.updationHistory != null)
				return false;
		} else if (!updationHistory.equals(other.updationHistory))
			return false;
		return true;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getOffshoreOwner() {
		return OffshoreOwner;
	}
	public void setOffshoreOwner(String offshoreOwner) {
		OffshoreOwner = offshoreOwner;
	}
	public String getOnshoreOwner() {
		return onshoreOwner;
	}
	public void setOnshoreOwner(String onshoreOwner) {
		this.onshoreOwner = onshoreOwner;
	}
	public String getAssignedBy() {
		return assignedBy;
	}
	public void setAssignedBy(String assignedBy) {
		this.assignedBy = assignedBy;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getUpdationHistory() {
		return updationHistory;
	}
	public void setUpdationHistory(String updationHistory) {
		this.updationHistory = updationHistory;
	}
}
